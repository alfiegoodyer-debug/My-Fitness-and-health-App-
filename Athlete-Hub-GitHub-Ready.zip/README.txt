ATHLETE HUB — READY-TO-RUN APP

This is a complete React/Vite starter app with:
- Home dashboard
- Training
- Sports
- Fuel
- Recovery
- Progress + milestones + lessons
- Equipment
- Settings
- Responsive mobile/desktop UI
- Local browser saving

I have included the project files so you don't have to write the code.

To run it on a Windows computer:
1. Install Node.js if it isn't already installed.
2. Open this folder in VS Code.
3. Open a terminal in the folder.
4. Run: npm install
5. Run: npm run dev
6. Open the localhost address Vite gives you.

The app saves its data in the browser's localStorage.
