import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const defaultData = {
  training: [],
  sports: [],
  fuel: [],
  recovery: [],
  milestones: [],
  lessons: [],
  equipment: [],
  profile: { name: "Athlete", sport: "Multi-sport" }
};

const nav = [
  ["home", "⌂", "Home"],
  ["training", "◒", "Training"],
  ["sports", "◆", "Sports"],
  ["fuel", "◉", "Fuel"],
  ["recovery", "☾", "Recovery"],
  ["progress", "↗", "Progress"],
  ["more", "•••", "More"]
];

function loadData() {
  try {
    const saved = localStorage.getItem("athlete-hub-data");
    return saved ? { ...defaultData, ...JSON.parse(saved) } : defaultData;
  } catch {
    return defaultData;
  }
}

function App() {
  const [data, setData] = useState(loadData);
  const [page, setPage] = useState("home");
  const [toast, setToast] = useState("");

  useEffect(() => {
    localStorage.setItem("athlete-hub-data", JSON.stringify(data));
  }, [data]);

  const today = new Date().toISOString().slice(0, 10);

  function notify(message) {
    setToast(message);
    setTimeout(() => setToast(""), 2200);
  }

  function add(type, item) {
    setData(d => ({ ...d, [type]: [{ ...item, id: crypto.randomUUID() }, ...d[type]] }));
    notify("Saved ✓");
  }

  function remove(type, id) {
    setData(d => ({ ...d, [type]: d[type].filter(x => x.id !== id) }));
    notify("Removed");
  }

  const completedWeek = useMemo(() => {
    const all = [...data.training, ...data.sports];
    return all.filter(x => x.date >= new Date(Date.now()-6*864e5).toISOString().slice(0,10) && x.completed).length;
  }, [data]);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark">A</div><div><b>ATHLETE</b><span>HUB</span></div></div>
        <nav>{nav.map(([id, icon, label]) =>
          <button key={id} className={page === id ? "nav active" : "nav"} onClick={() => setPage(id)}>
            <span>{icon}</span>{label}
          </button>
        )}</nav>
        <div className="sidebar-bottom">
          <button className="nav" onClick={() => setPage("settings")}><span>⚙</span>Settings</button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">PERSONAL PERFORMANCE SYSTEM</div>
            <h1>{page === "home" ? "Good to see you." : nav.find(x => x[0] === page)?.[2] || "Settings"}</h1>
          </div>
          <div className="profile-chip" onClick={() => setPage("settings")}>
            <div className="avatar">{data.profile.name.slice(0,1).toUpperCase()}</div>
            <span>{data.profile.name}</span>
          </div>
        </header>

        {page === "home" && <Home data={data} today={today} completedWeek={completedWeek} go={setPage} />}
        {page === "training" && <Training data={data} add={add} remove={remove} today={today} />}
        {page === "sports" && <Sports data={data} add={add} remove={remove} today={today} />}
        {page === "fuel" && <Fuel data={data} add={add} remove={remove} today={today} />}
        {page === "recovery" && <Recovery data={data} add={add} remove={remove} today={today} />}
        {page === "progress" && <Progress data={data} add={add} remove={remove} today={today} />}
        {page === "more" && <More data={data} add={add} remove={remove} today={today} go={setPage} />}
        {page === "settings" && <Settings data={data} setData={setData} notify={notify} />}

        {toast && <div className="toast">{toast}</div>}
      </main>

      <div className="mobile-nav">
        {nav.slice(0,6).map(([id, icon, label]) =>
          <button key={id} className={page === id ? "mobile-active" : ""} onClick={() => setPage(id)}>
            <span>{icon}</span><small>{label}</small>
          </button>
        )}
      </div>
    </div>
  );
}

function Home({data,today,completedWeek,go}) {
  const todayTraining = data.training.filter(x => x.date === today);
  const todaySport = data.sports.filter(x => x.date === today);
  const latestRecovery = data.recovery[0];

  return <div className="content">
    <section className="hero-grid">
      <div className="hero-card">
        <div className="eyebrow">TODAY · {new Date().toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"short"})}</div>
        <h2>Train smart.<br/><em>Keep progressing.</em></h2>
        <p>Your personal place to log training, sport, fuel and recovery.</p>
        <div className="quick-row">
          <button className="primary" onClick={() => go("training")}>+ Log training</button>
          <button className="ghost" onClick={() => go("recovery")}>Check recovery</button>
        </div>
      </div>
      <div className="readiness-card">
        <div className="eyebrow">LATEST RECOVERY</div>
        <div className="big-stat">{latestRecovery?.energy || "—"}</div>
        <p>{latestRecovery ? `${latestRecovery.sleep} sleep · ${latestRecovery.soreness} soreness` : "Add a recovery check-in"}</p>
        <button className="text-btn" onClick={() => go("recovery")}>Open recovery →</button>
      </div>
    </section>

    <section className="stats">
      <Stat label="This week" value={completedWeek} suffix=" sessions" />
      <Stat label="Milestones" value={data.milestones.length} suffix="" />
      <Stat label="Fuel logs" value={data.fuel.filter(x=>x.date===today).length} suffix=" today" />
      <Stat label="Lessons" value={data.lessons.length} suffix="" />
    </section>

    <section className="section-head"><div><div className="eyebrow">COMMAND CENTRE</div><h2>Quick actions</h2></div></section>
    <div className="action-grid">
      <Action icon="◒" title="Training" text="Gym & strength sessions" go={()=>go("training")}/>
      <Action icon="◆" title="Sports" text="Football, tennis, rugby & more" go={()=>go("sports")}/>
      <Action icon="◉" title="Fuel" text="Meals and food variety" go={()=>go("fuel")}/>
      <Action icon="☾" title="Recovery" text="Sleep, energy & soreness" go={()=>go("recovery")}/>
      <Action icon="↗" title="Progress" text="Milestones and lessons" go={()=>go("progress")}/>
      <Action icon="•••" title="More" text="Equipment and notes" go={()=>go("more")}/>
    </div>

    <section className="section-head"><div><div className="eyebrow">TODAY</div><h2>What’s happening</h2></div></section>
    <div className="timeline">
      {[...todayTraining.map(x=>({...x,kind:"Training"})),...todaySport.map(x=>({...x,kind:"Sport"}))].map(x =>
        <div className="list-row" key={x.id}><span className="dot"/><div><b>{x.name || x.session || x.activity}</b><small>{x.kind} · {x.duration || "—"} min</small></div><span className="pill">{x.completed ? "Completed" : "Planned"}</span></div>
      )}
      {todayTraining.length+todaySport.length===0 && <Empty text="Nothing logged for today yet."/>}
    </div>
  </div>
}

function Stat({label,value,suffix}) { return <div className="stat"><span>{label}</span><strong>{value}</strong><small>{suffix}</small></div> }
function Action({icon,title,text,go}) { return <button className="action-card" onClick={go}><span className="action-icon">{icon}</span><div><b>{title}</b><small>{text}</small></div><span className="arrow">→</span></button> }

function Training({data,add,remove,today}) {
  const [form,setForm]=useState({name:"",date:today,type:"Strength",duration:"",goal:"Strength",effort:"Moderate",completed:true,notes:""});
  return <Page title="Training" eyebrow="TRAINING LOG" subtitle="Record gym and training sessions.">
    <FormCard title="Log a session">
      <input placeholder="Session name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
      <div className="form-grid"><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/><input type="number" placeholder="Duration (min)" value={form.duration} onChange={e=>setForm({...form,duration:e.target.value})}/></div>
      <div className="form-grid"><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{["Strength","Conditioning","Running","Other"].map(x=><option key={x}>{x}</option>)}</select><select value={form.effort} onChange={e=>setForm({...form,effort:e.target.value})}>{["Easy","Moderate","Hard"].map(x=><option key={x}>{x}</option>)}</select></div>
      <textarea placeholder="What did you do? Notes..." value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
      <button className="primary" onClick={()=>{if(!form.name.trim())return;add("training",form);setForm({...form,name:"",notes:""})}}>Save training</button>
    </FormCard>
    <List title="Recent sessions" items={data.training} remove={id=>remove("training",id)} render={x=><><b>{x.name}</b><small>{x.date} · {x.type} · {x.duration||"—"} min · {x.effort}</small></>}/>
  </Page>
}

function Sports({data,add,remove,today}) {
  const [form,setForm]=useState({name:"",date:today,sport:"Football",duration:"",type:"Training",completed:true,notes:""});
  return <Page title="Sports" eyebrow="SPORT SESSIONS" subtitle="Keep your match and training history together.">
    <FormCard title="Log a sport session">
      <input placeholder="Session name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
      <div className="form-grid"><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/><input type="number" placeholder="Duration (min)" value={form.duration} onChange={e=>setForm({...form,duration:e.target.value})}/></div>
      <div className="form-grid"><select value={form.sport} onChange={e=>setForm({...form,sport:e.target.value})}>{["Football","Tennis","Rugby","Running","Other"].map(x=><option key={x}>{x}</option>)}</select><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>Training</option><option>Match</option><option>Other</option></select></div>
      <textarea placeholder="Notes" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
      <button className="primary" onClick={()=>{if(!form.name.trim())return;add("sports",form);setForm({...form,name:"",notes:""})}}>Save sport session</button>
    </FormCard>
    <List title="Recent sport" items={data.sports} remove={id=>remove("sports",id)} render={x=><><b>{x.name}</b><small>{x.date} · {x.sport} · {x.type} · {x.duration||"—"} min</small></>}/>
  </Page>
}

function Fuel({data,add,remove,today}) {
  const [form,setForm]=useState({meal:"",date:today,type:"Lunch",categories:[],notes:""});
  const cats=["Protein","Carbohydrates","Fruit & vegetables","Fats","Fluids"];
  const toggle=c=>setForm(f=>({...f,categories:f.categories.includes(c)?f.categories.filter(x=>x!==c):[...f.categories,c]}));
  return <Page title="Fuel" eyebrow="FUEL LOG" subtitle="Track variety and remember to fuel for your sport.">
    <FormCard title="Add a meal">
      <input placeholder="Meal or snack" value={form.meal} onChange={e=>setForm({...form,meal:e.target.value})}/>
      <div className="form-grid"><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{["Breakfast","Lunch","Dinner","Snack"].map(x=><option key={x}>{x}</option>)}</select></div>
      <label className="label">What’s included?</label><div className="chips">{cats.map(c=><button type="button" className={form.categories.includes(c)?"chip selected":"chip"} onClick={()=>toggle(c)} key={c}>{c}</button>)}</div>
      <textarea placeholder="Optional notes" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
      <button className="primary" onClick={()=>{if(!form.meal.trim())return;add("fuel",form);setForm({...form,meal:"",notes:"",categories:[]})}}>Save meal</button>
    </FormCard>
    <List title="Recent meals" items={data.fuel} remove={id=>remove("fuel",id)} render={x=><><b>{x.meal}</b><small>{x.date} · {x.type} · {x.categories.join(" · ")||"No categories selected"}</small></>}/>
    <div className="notice">This is a variety/fuelling log, not a calorie counter or body-weight tracker.</div>
  </Page>
}

function Recovery({data,add,remove,today}) {
  const [form,setForm]=useState({date:today,sleep:"Good",energy:"Good",soreness:"None",mood:"Good",ready:"Yes",notes:""});
  return <Page title="Recovery" eyebrow="READINESS" subtitle="Notice how you’re feeling before stacking more training.">
    <FormCard title="Daily check-in">
      <input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/>
      <div className="form-grid">{["sleep","energy","soreness","mood"].map(k=><select key={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}>{(k==="sleep"?["Poor","Okay","Good"]:k==="energy"?["Low","Normal","Good"]:k==="soreness"?["None","Mild","Noticeable","Pain — tell an adult/coach"]:["Low","Okay","Good","Great"]).map(x=><option key={x}>{x}</option>)}</select>)}</div>
      <select value={form.ready} onChange={e=>setForm({...form,ready:e.target.value})}><option>Yes</option><option>Maybe</option><option>Talk to adult/coach</option></select>
      <textarea placeholder="Anything worth noting?" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
      <button className="primary" onClick={()=>{add("recovery",form);setForm({...form,notes:""})}}>Save check-in</button>
    </FormCard>
    <List title="Recent check-ins" items={data.recovery} remove={id=>remove("recovery",id)} render={x=><><b>{x.date} · {x.energy} energy</b><small>{x.sleep} sleep · {x.soreness} soreness · Ready: {x.ready}</small></>}/>
  </Page>
}

function Progress({data,add,remove,today}) {
  const [form,setForm]=useState({name:"",date:today,category:"Technique",status:"Achieved",what:"",next:""});
  return <Page title="Progress" eyebrow="PROGRESS & MILESTONES" subtitle="Track skills, consistency and things you’re learning.">
    <FormCard title="Add a milestone">
      <input placeholder="Milestone" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
      <div className="form-grid"><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{["Strength","Technique","Sport Skill","Performance","Consistency","Other"].map(x=><option key={x}>{x}</option>)}</select><select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option>Goal</option><option>In Progress</option><option>Achieved</option></select></div>
      <textarea placeholder="What improved?" value={form.what} onChange={e=>setForm({...form,what:e.target.value})}/>
      <input placeholder="Next step" value={form.next} onChange={e=>setForm({...form,next:e.target.value})}/>
      <button className="primary" onClick={()=>{if(!form.name.trim())return;add("milestones",form);setForm({...form,name:"",what:"",next:""})}}>Save milestone</button>
    </FormCard>
    <List title="Milestones" items={data.milestones} remove={id=>remove("milestones",id)} render={x=><><b>{x.name}</b><small>{x.category} · {x.status} · {x.date}</small>{x.what&&<p>{x.what}</p>}</>}/>
    <div className="section-head"><div><div className="eyebrow">LEARNING</div><h2>What I learned</h2></div></div>
    <LessonForm add={add} today={today}/>
    <List title="Lessons" items={data.lessons} remove={id=>remove("lessons",id)} render={x=><><b>{x.name}</b><small>{x.date} · {x.category}</small><p>{x.what}</p></>}/>
  </Page>
}

function LessonForm({add,today}) {
 const [f,setF]=useState({name:"",date:today,category:"Technique",what:"",next:""});
 return <FormCard title="Save a lesson">
   <input placeholder="Lesson title" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/>
   <div className="form-grid"><input type="date" value={f.date} onChange={e=>setF({...f,date:e.target.value})}/><select value={f.category} onChange={e=>setF({...f,category:e.target.value})}>{["Technique","Tactics","Training","Recovery","Match","Nutrition","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
   <textarea placeholder="What did you learn?" value={f.what} onChange={e=>setF({...f,what:e.target.value})}/>
   <input placeholder="Try next time" value={f.next} onChange={e=>setF({...f,next:e.target.value})}/>
   <button className="primary" onClick={()=>{if(!f.name.trim())return;add("lessons",f);setF({...f,name:"",what:"",next:""})}}>Save lesson</button>
 </FormCard>
}

function More({data,add,remove,today,go}) {
 const [f,setF]=useState({name:"",category:"Gym",condition:"Good",checked:today,notes:""});
 return <Page title="More" eyebrow="ATHLETE TOOLKIT" subtitle="Everything else that keeps your system useful.">
   <div className="action-grid compact">
     <Action icon="🎒" title="Equipment" text="Keep track of kit condition" go={()=>document.getElementById("equipment-form")?.scrollIntoView({behavior:"smooth"})}/>
     <Action icon="📝" title="Notes" text="Use lessons for things you want to remember" go={()=>go("progress")}/>
     <Action icon="⚙" title="Settings" text="Personalise your hub" go={()=>go("settings")}/>
   </div>
   <div id="equipment-form"><FormCard title="Add equipment">
    <input placeholder="Equipment name" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/>
    <div className="form-grid"><select value={f.category} onChange={e=>setF({...f,category:e.target.value})}>{["Gym","Tennis","Football","Rugby","Recovery","Other"].map(x=><option key={x}>{x}</option>)}</select><select value={f.condition} onChange={e=>setF({...f,condition:e.target.value})}>{["Good","Needs Attention","Replace Soon"].map(x=><option key={x}>{x}</option>)}</select></div>
    <input type="date" value={f.checked} onChange={e=>setF({...f,checked:e.target.value})}/>
    <textarea placeholder="Notes" value={f.notes} onChange={e=>setF({...f,notes:e.target.value})}/>
    <button className="primary" onClick={()=>{if(!f.name.trim())return;add("equipment",f);setF({...f,name:"",notes:""})}}>Save equipment</button>
   </FormCard></div>
   <List title="Equipment" items={data.equipment} remove={id=>remove("equipment",id)} render={x=><><b>{x.name}</b><small>{x.category} · {x.condition} · checked {x.checked}</small></>}/>
 </Page>
}

function Settings({data,setData,notify}) {
 const [name,setName]=useState(data.profile.name);
 return <Page title="Settings" eyebrow="PERSONALISE" subtitle="Your data stays in this browser on this device.">
   <FormCard title="Profile">
     <label className="label">Name</label><input value={name} onChange={e=>setName(e.target.value)}/>
     <button className="primary" onClick={()=>{setData({...data,profile:{...data.profile,name:name||"Athlete"}});notify("Profile saved ✓")}}>Save profile</button>
   </FormCard>
   <div className="danger-card"><h3>Data</h3><p>Your Athlete Hub uses local browser storage. Nothing is sent to a server by this starter app.</p><button className="ghost danger" onClick={()=>{if(confirm("Clear all Athlete Hub data?")){localStorage.removeItem("athlete-hub-data");location.reload()}}}>Clear all data</button></div>
 </Page>
}

function Page({title,eyebrow,subtitle,children}) { return <div className="content"><div className="page-intro"><div className="eyebrow">{eyebrow}</div><h2>{title}</h2><p>{subtitle}</p></div>{children}</div> }
function FormCard({title,children}) { return <section className="form-card"><h3>{title}</h3>{children}</section> }
function List({title,items,remove,render}) { return <section className="list-section"><div className="section-head"><h3>{title}</h3><span>{items.length}</span></div>{items.length?items.map(x=><div className="list-row" key={x.id}><span className="dot"/><div className="row-main">{render(x)}</div><button className="delete" onClick={()=>remove(x.id)}>×</button></div>):<Empty text="Nothing here yet."/>}</section> }
function Empty({text}) { return <div className="empty">{text}</div> }

createRoot(document.getElementById("root")).render(<App />);
